Run `java -jar searoute.jar -h` to see the help.

See also the [online documentation](https://github.com/eurostat/searoute).
