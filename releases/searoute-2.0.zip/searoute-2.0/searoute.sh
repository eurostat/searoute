#!/usr/bin/env bash
java -jar searoute.jar -i "test_input.csv" -res 5 -panama 0
